# HM Land Registry Price Paid Data
Data for 2017 sales prices.
## Source 
https://data.gov.uk/dataset/land-registry-monthly-price-paid-data/resource/1ad0f2e9-74aa-4a36-8ab1-076bd24e289f