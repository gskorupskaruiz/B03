class DataProvider(object):
    pass