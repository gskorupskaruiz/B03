# GP-EnKF
Implementation of the Gaussian processes regression with inducing points for online data with ensemble Kalman filter estimation. Code for the Ensemble Kalman Filtering for Online Gaussian Process Regression and Learning (Fusion 2018) paper.
